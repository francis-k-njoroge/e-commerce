<?php
include 'conn.php';

// Fetch categories for the dropdown
$query = "SELECT category_name FROM main_categories";
$result = mysqli_query($conn, $query);
$categories = array();
while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row['category_name'];
}
echo json_encode($categories);

// Check if the request method is POST for adding a product
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate database connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get and sanitize the form data
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);
    $buying_price = mysqli_real_escape_string($conn, $_POST['price']);
    $sale_price = mysqli_real_escape_string($conn, $_POST['sale_price']);
    $stock_quantity = mysqli_real_escape_string($conn, $_POST['stock_quantity']);
    $is_featured = mysqli_real_escape_string($conn, $_POST['is_featured']);
    $is_on_sale = mysqli_real_escape_string($conn, $_POST['is_on_sale']);
    
    // Prepare current timestamp
    $created_at = date("Y-m-d H:i:s");
    $updated_at = date("Y-m-d H:i:s");

    // Handle image upload
    $image_url = '';
    if (isset($_FILES['image_url']['name']) && $_FILES['image_url']['error'] == 0) {
        $image_name = basename($_FILES['image_url']['name']);
        $image_ext = pathinfo($image_name, PATHINFO_EXTENSION);
        $image_path = '../../img/' . $image_name;

        // Validate the file type (e.g., allow only certain formats)
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($image_ext, $allowed_types)) {
            // Move the uploaded file to the specified directory
            if (move_uploaded_file($_FILES['image_url']['tmp_name'], $image_path)) {
                $image_url = 'img/' . $image_name; // Save relative path to the database
            } else {
                echo "Error uploading image.";
                exit;
            }
        } else {
            echo "Invalid image format. Only JPG, PNG, and GIF are allowed.";
            exit;
        }
    }

    // Use prepared statements to insert data into the database
    $stmt = $conn->prepare("INSERT INTO product (product_name, description, buying_price, stock_quantity, image_url, category_name, is_featured, is_on_sale, sale_price, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    if ($stmt) {
        $stmt->bind_param("ssddsssssss", $product_name, $description, $buying_price, $stock_quantity, $image_url, $category_name, $is_featured, $is_on_sale, $sale_price, $created_at, $updated_at);

        if ($stmt->execute()) {
            header("Location: ../auth/add_stock.php");
              exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
