<?php

function trimText($text, $length = 50)
{
    if (strlen($text) > $length) {
        return substr($text, 0, $length) . '...';
    }
    return $text;
}

function displayTable($conn, $sql, $headers, $trimColumns = [], $imageColumns = [], $basePath = '')
{
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        echo "Error: " . mysqli_error($conn);
        return;
    }

    // Get the primary key column name (assuming it's the first column)
    $firstRow = mysqli_fetch_assoc(mysqli_query($conn, $sql));
    $primaryKeyColumn = array_key_first($firstRow);
    $columns = array_keys($firstRow);
    
    // Reset the result pointer
    mysqli_data_seek($result, 0);

    $headers[] = 'Actions';

    // Main table structure
    echo '<!-- Responsive Table Start -->';
    echo '<div class="container-fluid pt-4 p-5 px-4">';
    echo '    <div class="row g-4">';
    echo '        <div class="col-sm-12 col-md-12 col-xl-12">';
    echo '            <div class="border border-primary rounded p-4">';
    echo '                <h4 class="mb-4">Data List</h4>';
    echo '                <div class="table-responsive">';
    echo '                    <table id="dataTable" class="table table-bordered table-hover table-striped">';
    echo '                        <thead class="bg-primary text-light">';
    echo '                            <tr>';
    
    foreach ($headers as $header) {
        echo '                                <th scope="col">' . htmlspecialchars($header) . '</th>';
    }
    
    echo '                            </tr>';
    echo '                        </thead>';
    echo '                        <tbody>';

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        $i = 0;
        $id = $row[$primaryKeyColumn];
        
        foreach ($row as $key => $column) {
            if (in_array($i, $imageColumns)) {
                $imagePath = $basePath . $column;
                echo '<td><img src="' . htmlspecialchars($imagePath) . '" alt="' . htmlspecialchars($row['name'] ?? 'Image') . '" style="width:100px; height:auto;"></td>';
            } else if (in_array($i, $trimColumns)) {
                echo '<td>' . htmlspecialchars(trimText($column)) . '</td>';
            } else {
                echo '<td>' . htmlspecialchars($column) . '</td>';
            }
            $i++;
        }

        // Add action buttons with data attributes
        echo '<td class="d-inline-flex align-items-center">';
        echo '    <button class="btn btn-outline-primary btn-sm mx-1" 
                          onclick="editRecord(this)" 
                          data-id="' . htmlspecialchars($id) . '"
                          data-row=\'' . json_encode($row) . '\'>
                    <i class="fas fa-edit"></i>
                  </button>';
        echo '    <button class="btn btn-outline-danger btn-sm mx-1" 
                          onclick="deleteRecord(this)" 
                          data-id="' . htmlspecialchars($id) . '" 
                          
                          data-pk="' . htmlspecialchars($primaryKeyColumn) . '">
                    <i class="fas fa-trash-alt"></i>
                  </button>';
       
        echo '</td>';
        echo '</tr>';
    }

    echo '                        </tbody>';
    echo '                    </table>';
    echo '                </div>';
    echo '            </div>';
    echo '        </div>';
    echo '    </div>';
    echo '</div>';
    echo '<!-- Responsive Table End -->';

}
    ?>
