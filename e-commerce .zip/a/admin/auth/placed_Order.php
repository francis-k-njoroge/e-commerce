<?php
include "header.php";
?>

<!-- Sale & Revenue Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-6 col-xl-3">
            <div class="border border-primary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-chart-line fa-3x text-primary"></i>
                <div class="ms-3">
                    <p class="mb-2">Placed Order</p>
                    <h6 class="mb-0">34</h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="border border-primary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-chart-bar fa-3x text-primary"></i>
                <div class="ms-3">
                    <p class="mb-2">Undelivered</p>
                    <h6 class="mb-0">234</h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="border border-primary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-chart-area fa-3x text-primary"></i>
                <div class="ms-3">
                    <p class="mb-2">Total Stock</p>
                    <h6 class="mb-0">2,340,000</h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="border border-primary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-chart-pie fa-3x text-primary"></i>
                <div class="ms-3">
                    <p class="mb-2">Support</p>
                    <h6 class="mb-0">4</h6>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Sale & Revenue End -->
<!-- Responsive Table Start -->
<div class="container-fluid pt-4 p-5 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-md-12 col-xl-12">
            <div class="border border-primary rounded p-4">
                <h4 class="mb-4">Order List</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th scope="col">Order ID</th>
                                <th scope="col">User ID</th>
                                <th scope="col">Total Amount</th>
                                <th scope="col">Order Status</th>
                                <th scope="col">Created At</th>
                                <th scope="col">Updated At</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Random Data Row 1 -->
                            <tr>
                                <td>201</td>
                                <td>501</td>
                                <td>$1200</td>
                                <td>Shipped</td>
                                <td>2024-10-01 14:20:00</td>
                                <td>2024-10-02 16:30:00</td>
                                <td>
                                    <button class="btn btn-outline-primary rounded-pill" data-bs-toggle="modal"
                                        data-bs-target="#orderModal">
                                        View Order
                                    </button>
                                </td>
                            </tr>
                            <!-- Random Data Row 2 -->
                            <tr>
                                <td>202</td>
                                <td>502</td>
                                <td>$300</td>
                                <td>Pending</td>
                                <td>2024-10-02 10:00:00</td>
                                <td>2024-10-02 12:00:00</td>
                                <td>
                                    <button class="btn btn-outline-primary rounded-pill" data-bs-toggle="modal"
                                        data-bs-target="#orderModal">
                                        View Order
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Responsive Table End -->

 <!-- Modal Structure -->
 <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header bg-primary ">
                <h5 class="modal-title text-white" id="orderModalLabel">Order Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body p-4">
                <div class="row g-4">
                    <!-- Left Column (Order & Customer Info) -->
                    <div class="col-md-4">
                        <!-- Order Information -->
                        <div class="border border-info rounded mb-4 p-3">
                            <h6 class="mb-3 text-primary">Order Information</h6>
                            <table class="table table-sm">
                                <tbody>
                                    <tr>
                                        <th scope="row">Order ID:</th>
                                        <td><strong>201</strong></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Total Amount:</th>
                                        <td><strong>$1200</strong></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Order Status:</th>
                                        <td><span class="badge bg-primary">Shipped</span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Created At:</th>
                                        <td>2024-10-01 14:20</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Updated At:</th>
                                        <td>2024-10-02 16:30</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Customer Information -->
                        <div class="border border-info rounded p-3">
                            <h6 class="mb-3 text-primary">Customer Information</h6>
                            <table class="table table-sm">
                                <tbody>
                                    <tr>
                                        <th scope="row">Name:</th>
                                        <td><strong>John Doe</strong></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Email:</th>
                                        <td>john.doe@example.com</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Phone:</th>
                                        <td>+123456789</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Address:</th>
                                        <td>123 Main Street</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Right Column (Order Items) -->
                    <div class="col-md-8">
                        <div class="border border-info rounded p-3">
                            <h6 class="mb-3 text-primary">Order Items</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-hover align-middle">
                                    <thead class="bg-primary text-light">
                                        <tr>
                                            <th scope="col">Product ID</th>
                                            <th scope="col">Product Name</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1001</td>
                                            <td>ABCD Furniture Model AA3</td>
                                            <td>2</td>
                                            <td>$600</td>
                                        </tr>
                                        <tr>
                                            <td>1002</td>
                                            <td>XYZ Furniture Model BB4</td>
                                            <td>1</td>
                                            <td>$600</td>
                                        </tr>
                                        <tr>
                                            <td>1002</td>
                                            <td>XYZ Furniture Model BB4</td>
                                            <td>1</td>
                                            <td>$600</td>
                                        </tr>
                                        <tr>
                                            <td>1002</td>
                                            <td>XYZ Furniture Model BB4</td>
                                            <td>1</td>
                                            <td>$600</td>
                                        </tr>
                                        <tr>
                                            <td>1002</td>
                                            <td>XYZ Furniture Model BB4</td>
                                            <td>1</td>
                                            <td>$600</td>
                                        </tr>
                                        <tr>
                                            <td>1002</td>
                                            <td>XYZ Furniture Model BB4</td>
                                            <td>1</td>
                                            <td>$600</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Footer with Action Buttons -->
            <div class="modal-footer d-flex ">
                <button type="button" class="btn btn-outline-primary rounded-pill">Process Order</button>
                <button type="button" class="btn btn-outline-danger rounded-pill">Reject Order</button>
                <button type="button" class="btn btn-outline-secondary rounded-pill" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>



<?php
include "footer.php";
?>