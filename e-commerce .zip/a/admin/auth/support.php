<?php
include "header.php";

?>
<!-- Recent Sales Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="border border-primary rounded text-center  p-4">
                    <div class="d-flex align-items-center justify-content-center mb-4">
                        <h6 class="py-5 align-items-center" style="font-size: 7rem;" >Comming Soon !!!!</h6>
                       
                    </div>
                    
                </div>
            </div>
           
            <!-- Recent Sales End -->
<?php
include "footer.php";
?>