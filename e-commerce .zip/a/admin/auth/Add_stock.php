<?php
include "header.php";
?>
<!-- add category Start -->
<div class="container-fluid pt-4 mt-2 p-5 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-md-12 border border-primary rounded col-xl-12">
            <div class="rounded p-4">
                <h4 class="mb-4 text-dark">Add Stock</h4>
                <form action="../php/stock.php" method="POST" enctype="multipart/form-data">
                    <div class="row mt-2 p-3 text-start">
                        <!-- Column 1: Basic Information -->
                        <div class="col-md-4">
                            <h4 class="mb-3">Basic Information</h4>
                            <div class="form-group">
                                <label for="product_name">Product Name</label>
                                <input type="text" class="form-control" id="product_name"
                                    name="product_name" required />
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="3"
                                    required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="category_id">Category</label>
                                <select class="form-control bg-gray rounded-0 text-dark" id="category_name"
                                    name="category_name" required>
                                    <option value="">Select a category</option>
                                    <!-- Options will be dynamically populated here -->
                                </select>
                            </div>
                        </div>

                        <!-- Column 2: Pricing and Stock -->
                        <div class="col-md-4">
                            <h4 class="mb-3">Pricing and Stock</h4>
                            <div class="form-group">
                                <label for="price">Buying Price</label>
                                <div class="input-group">
                                    <span class="input-group-text">Kes</span>
                                    <input type="number" step="0.01" class="form-control" id="price"
                                        name="price" required />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="sale_price">Sale Price</label>
                                <div class="input-group">
                                    <span class="input-group-text">Kes</span>
                                    <input type="number" step="0.01" class="form-control" id="sale_price"
                                        name="sale_price" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="stock_quantity">Stock Quantity</label>
                                <input type="number" class="form-control" id="stock_quantity"
                                    name="stock_quantity" required />
                            </div>
                        </div>

                        <!-- Column 3: Product Details and Image -->
                        <div class="col-md-4">
                            <h4 class="mb-3">Product Details</h4>
                            <div class="form-group">
                                <label for="is_featured">Featured Product</label>
                                <select class="form-control" id="is_featured" name="is_featured">
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="is_on_sale">On Sale</label>
                                <select class="form-control" id="is_on_sale" name="is_on_sale">
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="image_url">Product Image</label>
                                <input type="file" class="form-control" id="image_url" name="image_url"
                                    required />
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4 text-start p-2">
                        <div class="col-12">
                            <button type="submit"
                                class="btn btn-custom border-secondary rounded-pill text-primary">
                                Add Product
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- add category End -->

<script>
    function fetchCategories() {
        // Create an XMLHttpRequest object
        const xhr = new XMLHttpRequest();

        // Define the type of request, the URL, and if it should be asynchronous
        xhr.open("GET", "../php/stock.php", true);

        // Execute when the request is successful
        xhr.onload = function() {
            if (this.status === 200) {
                // Parse the JSON data returned from the PHP script
                const categories = JSON.parse(this.responseText);

                // Get the select element by its ID
                const select = document.getElementById('category_name');

                // Clear any existing options
                select.innerHTML = '<option value="">Select a category</option>';

                // Loop through the categories and create option elements
                categories.forEach(category => {
                    const option = document.createElement('option');
                    option.value = category;
                    option.textContent = category;
                    select.appendChild(option);
                });
            }
        };

        // Send the request
        xhr.send();
    }

    // Call the function to fetch categories when the page loads
    window.onload = fetchCategories;
</script>

<!-- Responsive User Table Start -->

<?php
include '../php/crud.php'; // include your database connection file
include "../php/conn.php";


// SQL query to get data from the 'product' table
$sql = "SELECT product_id, product_name, description, buying_price, sale_price, stock_quantity, image_url, category_name FROM product";

// Define the headers for the table dynamically
$headers = ['Product ID', 'Product Name', 'Description', 'Buying Price', 'Sale Price', 'Stock Quantity', 'Image', 'Category Name'];

// Specify which columns to trim and which ones contain images
$trimColumns = [2];  // Column 2 (Description) will be trimmed to 50 characters
$imageColumns = [6];  // Column 5 (Image URL) will display as an image

// Specify the base path for the images
$basePath = "../../";

// Call the universal displayTable function
displayTable($conn, $sql, $headers, $trimColumns, $imageColumns, $basePath);

?>

<!-- Responsive User Table End -->


<?php
include "footer.php";
?>