<?php
include "header.php";
?>
<!-- Responsive User Table Start -->

<?php
            include '../php/crud.php'; // include your database connection file
            include "../php/conn.php";

            // SQL query to fetch data from the "users" table
            $sql = "SELECT user_id, first_name, last_name, email, phone_number, address FROM users";

            // Define the table headers corresponding to the columns in the "users" table
            $headers = ['user_id', 'first_name', 'last_name', 'email', 'phone_number', 'address'];

            // Call the function to display the table
            displayTable($conn, $sql, $headers);
            ?>

            <!-- Responsive User Table End -->

<?php
include "footer.php";
?>