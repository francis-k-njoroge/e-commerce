<?php
include "header.php";
?>
<!-- Responsive User Table Start -->
<?php
 //  include '../php/crud.php'; // include your database connection file
  // include "../php/conn.php";

    // SQL query to get data from the 'order' table (you can customize the WHERE clause)
  //  $sql = "SELECT order_id, user_id, total_amount, order_status, created_at, updated_at FROM `order` WHERE order_status = 'completed'";

    // Define the headers for the table dynamically
  //  $headers = ['Order ID', 'User ID', 'Total Amount', 'Order Status', 'Created At', 'Updated At'];

    // Call the universal displayTable function
   // displayTable($conn, $sql, $headers);
?>


<!-- Responsive User Table End -->

<?php
include "footer.php";
?>