// Function to set active state in sidebar based on current URL
function setSidebarActiveState() {
    // Get current page path
    const currentPath = window.location.pathname;
    
    // Remove all active classes first
    document.querySelectorAll('.navbar-nav .active').forEach(item => {
        item.classList.remove('active');
    });
    
    // Helper function to set active state and handle parent dropdowns
    function setActiveState(element) {
        element.classList.add('active');
        
        // If item is in dropdown, activate parent dropdown
        const dropdownParent = element.closest('.nav-item.dropdown');
        if (dropdownParent) {
            dropdownParent.querySelector('.nav-link').classList.add('active');
        }
    }
    
    // Check if we're on dashboard/index
    if (currentPath.endsWith('index.php') || currentPath === '/') {
        const dashboardLink = document.querySelector('a[href="index.php"]');
        if (dashboardLink) setActiveState(dashboardLink);
        return;
    }
    
    // Find matching link for current page
    const links = document.querySelectorAll('.navbar-nav a');
    links.forEach(link => {
        const href = link.getAttribute('href');
        if (href && currentPath.includes(href)) {
            setActiveState(link);
        }
    });
}

// Run when DOM is loaded
document.addEventListener('DOMContentLoaded', setSidebarActiveState);

// If using history API navigation, you might also want this:
window.addEventListener('popstate', setSidebarActiveState);