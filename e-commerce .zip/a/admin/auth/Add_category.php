<?php
include "header.php";
?>
<?php
// Include database connection
require_once '../php/conn.php';
require_once '../php/crud.php'; // Your existing table display function file

// Initialize message variables
$message = '';
$messageClass = '';
$editMode = false;
$editId = null;

// Function to sanitize input data
function sanitize_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Function to generate category ID
function generateCategoryId($conn)
{
    $sql = "SELECT MAX(CAST(SUBSTRING(category_id, 4) AS UNSIGNED)) as max_id FROM main_categories";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $next_id = ($row['max_id'] ?? 0) + 1;
    return 'CAT' . str_pad($next_id, 4, '0', STR_PAD_LEFT);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category_name = sanitize_input($_POST['category_name']);
    $category_description = sanitize_input($_POST['category_description']);
    $current_timestamp = date('Y-m-d H:i:s');

    if (isset($_POST['edit_id']) && !empty($_POST['edit_id'])) {
        // Update existing category
        $edit_id = sanitize_input($_POST['edit_id']);
        $sql = "UPDATE main_categories SET 
                category_name=?, 
                category_description=?, 
                updated_at=? 
                WHERE category_id=?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("ssss", $category_name, $category_description, $current_timestamp, $edit_id);
        } else {
            // Debug SQL error in preparation
            echo "Error preparing statement: " . $conn->error;
        }
    } else {
        // Generate new category ID
        $category_id = generateCategoryId($conn);

        // Insert new category
        $sql = "INSERT INTO main_categories (category_id, category_name, category_description, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sssss", $category_id, $category_name, $category_description, $current_timestamp, $current_timestamp);
        } else {
            // Debug SQL error in preparation
            echo "Error preparing statement: " . $conn->error;
        }
    }

    // Execute statement
    if ($stmt->execute()) {
        $message = isset($_POST['edit_id']) ? "Category updated successfully!" : "Category added successfully!";
        $messageClass = "alert-success";
    } else {
        // Debug execution error
        $message = "Error: " . $stmt->error;
        $messageClass = "alert-danger";
    }
    $stmt->close();
}

?>
    <!-- Category Form Start -->
    <div class="container-fluid pt-4 mt-2 p-5 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-md-12 col-xl-12">
                <div class="border border-primary rounded p-4">
                    <h4 class="mb-4 text-dark" id="formTitle">Add Category</h4>

                    <?php if (!empty($message)): ?>
                        <div class="alert <?php echo $messageClass; ?> alert-dismissible fade show" role="alert">
                            <?php echo $message; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="" id="categoryForm">
                        <input type="hidden" name="edit_id" id="edit_id">

                        <!-- Category ID Display (readonly in edit mode) -->
                        <div class="mb-3" id="categoryIdDisplay" style="display: none;">
                            <label class="form-label text-dark">Category ID</label>
                            <input type="text" class="form-control" id="category_id_display" readonly>
                        </div>

                        <!-- Category Name Input -->
                        <div class="mb-3">
                            <label for="category_name" class="form-label text-dark">Category Name</label>
                            <input type="text" class="form-control" id="category_name" name="category_name"
                                placeholder="Enter category name" required>
                        </div>

                        <!-- Category Description Input -->
                        <div class="mb-3">
                            <label for="category_description" class="form-label text-dark">Category Description</label>
                            <textarea class="form-control" id="category_description" name="category_description" rows="3"
                                placeholder="Enter category description" required></textarea>
                        </div>

                        <!-- Submit Buttons -->
                        <div class="btn-group">
                            <button type="submit" class="btn btn-custom border-secondary rounded-pill text-primary" id="addBtn">Add Category</button>
                            <button type="submit" class="btn btn-warning rounded-pill text-dark mx-2" id="updateBtn" style="display: none;">Update Category</button>
                            <button type="button" class="btn btn-secondary rounded-pill" id="cancelBtn" style="display: none;" onclick="cancelEdit()">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Category Form End -->

    <?php
    // Display categories table
    $sql = "SELECT * FROM main_categories ORDER BY created_at DESC";
    $headers = ['Category ID', 'Category Name', 'Description', 'Created At', 'Updated At'];
    displayTable($conn, $sql, $headers, [2]); // Trim the description column
    ?>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Function to handle edit button click
        function editRecord(button) {
            const rowData = JSON.parse(button.getAttribute('data-row'));

            // Populate form fields
            document.getElementById('edit_id').value = rowData.category_id;
            document.getElementById('category_id_display').value = rowData.category_id;
            document.getElementById('category_name').value = rowData.category_name;
            document.getElementById('category_description').value = rowData.category_description;

            // Show category ID display in edit mode
            document.getElementById('categoryIdDisplay').style.display = 'block';

            // Update UI for edit mode
            document.getElementById('formTitle').textContent = 'Edit Category';
            document.getElementById('addBtn').style.display = 'none';
            document.getElementById('updateBtn').style.display = 'inline-block';
            document.getElementById('cancelBtn').style.display = 'inline-block';

            // Scroll to form
            document.querySelector('.container-fluid').scrollIntoView({
                behavior: 'smooth'
            });
        }

        // Function to handle cancel button click
        function cancelEdit() {
            // Reset form
            document.getElementById('categoryForm').reset();
            document.getElementById('edit_id').value = '';
            document.getElementById('categoryIdDisplay').style.display = 'none';

            // Update UI back to add mode
            document.getElementById('formTitle').textContent = 'Add Category';
            document.getElementById('addBtn').style.display = 'inline-block';
            document.getElementById('updateBtn').style.display = 'none';
            document.getElementById('cancelBtn').style.display = 'none';
        }

        // Auto-hide alerts after 3 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 3000);
            });
        });

        // Function to handle delete button click
        function deleteRecord(button) {
            if (confirm('Are you sure you want to delete this category?')) {
                const id = button.getAttribute('data-id');
                const pk = button.getAttribute('data-pk');
                // You can implement the delete functionality here
            }
        }
    </script>



<?php
include "footer.php";
?>