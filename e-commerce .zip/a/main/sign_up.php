<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>Fruitables - Vegetable Website Template</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="../lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="../css/style.css" rel="stylesheet">
    </head>

    <body>

     <!-- Sign Up Start -->
<div class="container-fluid">
    <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
        <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-6"> <!-- Adjusted column size -->
            <div class="rounded p-4 p-sm-5 my-4 mx-3" style="background-color: black;">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <a href="../index.php" class="">
                        <h3 class="text-white"><i class="fa fa-hammer me-2"></i>XYZ Furniture</h3>
                    </a>
                    <h3 class="text-white">Sign Up</h3>
                </div>

                <!-- Form Start -->
                <form id="registerForm">
                    <!-- Row for First and Last Name -->
                    <div class="row">
                        <!-- First Name -->
                        <div class="col-md-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="first_name" name="first_name" placeholder="First Name">
                                <label for="first_name">First Name</label>
                            </div>
                        </div>
                        <!-- Last Name -->
                        <div class="col-md-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name">
                                <label for="last_name">Last Name</label>
                            </div>
                        </div>
                    </div>

                    <!-- Row for Email and Phone Number -->
                    <div class="row">
                        <!-- Email -->
                        <div class="col-md-6">
                            <div class="form-floating mb-3">
                                <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com">
                                <label for="email">Email address</label>
                            </div>
                        </div>
                        <!-- Phone Number -->
                        <div class="col-md-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="phone_number" name="phone_number" placeholder="Phone Number">
                                <label for="phone_number">Phone Number</label>
                            </div>
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                        <label for="password">Password</label>
                    </div>

                    <!-- Address -->
                    <div class="form-floating mb-3">
                        <textarea class="form-control" placeholder="Enter your address" id="address" name="address" style="height: 100px;"></textarea>
                        <label for="address">Address</label>
                    </div>
                    
                    <!-- Submit Button -->
                    <button type="submit" class="btn border border-secondary rounded-pill px-3 text-primary py-3 w-100 mb-4">Sign Up</button>
                    <p class="text-center mb-0">Already have an Account? <a href="sign_in.php">Sign In</a></p>
                </form>
                <!-- Form End -->
            </div>
        </div>
    </div>
</div>
<!-- Sign Up End -->

<!-- jQuery & AJAX Script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function () {
    $('#registerForm').on('submit', function (e) {
        e.preventDefault(); // Prevent form submission

        // AJAX request for registration
        $.ajax({
            type: 'POST',
            url: '../php/register.php', // PHP file to handle registration
            data: {
                action: 'register', // Action to handle registration in PHP
                first_name: $('#first_name').val(),
                last_name: $('#last_name').val(),
                email: $('#email').val(),
                password: $('#password').val(),
                phone_number: $('#phone_number').val(),
                address: $('#address').val(),
            },
            dataType: 'json', // Expect JSON response
            success: function (response) {
                if (response.status == 'success') {
                    alert(response.message); // Success message
                    // Redirect to sign-in or dashboard, e.g., window.location = 'sign_in.php';
                } else {
                    alert(response.message); // Error message
                }
            },
            error: function () {
                alert('An error occurred while submitting the form');
            }
        });
    });
});
</script>





      
    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../lib/easing/easing.min.js"></script>
    <script src="../lib/waypoints/waypoints.min.js"></script>
    <script src="../lib/lightbox/js/lightbox.min.js"></script>
    <script src="../lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="../js/main.js"></script>
    </body>

</html>



 