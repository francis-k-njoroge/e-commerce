<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>XYZ funiture </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link href="../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
    <!--=============== CSS ===============-->
    <link rel="stylesheet" href="../home/assets/css/styles.css">
    <style>
        .image-container {
            width: 100%;
            height: 200px;
            /* Adjust this value as needed */
            overflow: hidden;
        }

        .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }

        .modal-dialog-right {
            position: fixed;
            right: 40px;
            top: 0;
            margin: 0;
            height: 100%;
        }

        .modal.fade .modal-dialog-right {
            transform: translateX(100%);
            transition: transform 0.3s ease-out;
        }

        .modal.show .modal-dialog-right {
            transform: translateX(0);
        }
    </style>

</head>

<body>
    <!--=============== HEADER ===============-->
    <header class="header" id="header">
        <nav class="nav container">
            <a href="#" class="nav__logo">XYZ Furniture</a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item">
                        <a href="../index.php" class="nav__link ">
                            <i class="fas fa-home nav__icon"></i>
                            <span class="nav__name">Home</span>
                        </a>
                    </li>

                    <li class="nav__item">
                        <a href="#shop" class="nav__link">
                            <i class="fas fa-store nav__icon"></i>
                            <span class="nav__name">Shop</span>
                        </a>
                    </li>

                    <li class="nav__item">
                        <a href="#checkout" class="nav__link active-link">
                            <i class="fas fa-cash-register nav__icon"></i>
                            <span class="nav__name">Checkout</span>
                        </a>
                    </li>

                    <li class="nav__item">
                        <a href="#contactme" class="nav__link">
                            <i class="fas fa-envelope nav__icon"></i>
                            <span class="nav__name">Contact Me</span>
                        </a>
                    </li>
                </ul>
            </div>

            <img src="../home/assets/img/perfil.png" alt="" class="nav__img">
        </nav>
    </header>

    <!-- Checkout Page Start -->
    <div class="container-fluid py-5 ">
        <div class="container py-5 mb-3 ">
            <h1 class="mb-5 text-center">Billing details</h1>
            <form action="#">
                <div class="row g-5">
                    <!-- Cart Summary -->
                    <div class="col-md-12 col-lg-8">
                        <div class="border rounded border-primary">
                            <div class="table-responsive">
                                <table class="table display">
                                    <thead class="text-primary">
                                        <tr>
                                            <th scope="col">Products</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Total</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Dynamic rows will be inserted here by JavaScript -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- Billing Details Form -->
                    <div class="col-md-12 col-lg-4 border border rounded border-primary">
                        <div class="row">
                            <div class="form-item">
                                <label class="form-label my-3">Full Name<sup>*</sup></label>
                                <input type="text" class="form-control" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-lg-6">
                                <div class="form-item w-100">
                                    <label class="form-label my-3">Phone Number<sup>*</sup></label>
                                    <input type="text" class="form-control" />
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-6">
                                <div class="form-item w-100">
                                    <label class="form-label my-3">County<sup>*</sup></label>
                                    <input type="text" class="form-control" />
                                </div>
                            </div>
                        </div>
                        <div class="form-item">
                            <label class="form-label my-3">Email Address<sup>*</sup></label>
                            <input type="email" class="form-control" />
                        </div>
                        <div class="form-item">
                            <label class="form-label my-3">Address <sup>*</sup></label>
                            <textarea class="form-control"
                                placeholder=" House Number Street Name, Town , nearest landmark "> </textarea>
                        </div>
                    </div>
                </div>
                <!-- Subtotal and Checkout -->
                <div class="text-center py-3 pt-5  ">
                    <h5>Subtotal: <span id="cartSubtotal">KES 0.00</span></h5>
                    <button type="button" class="btn border-dark py-3 px-4   text-primary">
                        Order Online
                    </button>
                    <button type="button" class="btn border-dark py-3 px-4 text-secondary">
                        Whatsapp Order
                    </button>
                </div>
            </form>
        </div>
    </div>
    <!-- Checkout Page End -->
<!-- Subtotal and Checkout -->
<div class="text-center py-3 pt-5  ">
                    
                    <button type="button" class="btn border-dark py-3 px-4   text-primary">
                        continue shopping 
                    </button>
                    
                </div>


    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5">
        <div class="container py-5">
            <div class="pb-4 mb-4" style="border-bottom: 1px solid rgba(226, 175, 24, 0.5) ;">
                <div class="row g-4">
                    <div class="col-lg-3">
                        <a href="#">
                            <h1 class="text-primary mb-0">XYZ Furniture</h1>
                            <p class="text-secondary mb-0">Quality products</p>
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <div class="position-relative mx-auto">
                            <input class="form-control border-0 w-100 py-3 px-4 rounded-pill" type="email " placeholder="Your Email">
                            <button type="submit" class="btn btn-primary border-0 border-secondary py-3 px-4 position-absolute rounded-pill text-white" style="top: 0; right: 0;">Subscribe Now</button>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="d-flex justify-content-end pt-3">
                            <a class="btn  btn-outline-secondary me-2 btn-md-square rounded-circle" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-secondary me-2 btn-md-square rounded-circle" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-secondary me-2 btn-md-square rounded-circle" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-secondary btn-md-square rounded-circle" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright bg-dark py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    <span class="text-light"><a href="#"><i class="fas fa-copyright text-light me-2"></i>Your Site Name</a>, All right reserved.</span>
                </div>
                <div class="col-md-6 my-auto text-center text-md-end text-white">
                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                    Designed By <a class="border-bottom" href="#">Amoh tech</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->

    <script>
        // Function to load items from localStorage into the cart table
        function loadCartTableFromLocalStorage() {
            let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
            let cartTableBody = document.querySelector('table tbody');
            let subtotalElement = document.getElementById('cartSubtotal');

            cartTableBody.innerHTML = ''; // Clear the table before inserting new items
            let subtotal = 0;

            if (cartItems.length === 0) {
                cartTableBody.innerHTML = '<tr><td colspan="5">Your cart is empty.</td></tr>';
            } else {
                cartItems.forEach(item => {
                    let itemTotal = item.price * item.quantity;

                    let rowHtml = `
            <tr>
                <td><img src="../${item.image}" alt="${item.name}" class="img-fluid" style="width: 50px;"></td>
                <td>${item.name}</td>
                <td>KES ${item.price}</td>
                <td>
                    <input type="number" disabled value="${item.quantity}" min="1" class="form-control" style="width: 60px;" onchange="updateQuantity(${item.id}, this.value)">
                </td>
                <td>KES ${itemTotal.toFixed(2)}</td>
                <td>
                    <button class="btn btn-danger btn-sm" onclick="deleteItem(${item.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            `;

                    cartTableBody.innerHTML += rowHtml;
                    subtotal += itemTotal; // Calculate subtotal
                });

                // Update the subtotal display
                subtotalElement.textContent = `KES ${subtotal.toFixed(2)}`;
            }

            // Optionally, update cart icon with the number of items
            updateCartIcon(cartItems.length);
        }

        // Function to update the cart icon in the navbar
        function updateCartIcon(itemCount) {
            let cartIcon = document.getElementById('cartIcon');
            if (cartIcon) {
                cartIcon.textContent = itemCount;
            }
        }

        // Call the function to load cart items from localStorage when the page loads
        window.onload = function() {
            loadCartTableFromLocalStorage(); // Load the cart from localStorage into the table
        };
    </script>

    <script src="home/assets/js/main.js"></script>

    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../lib/easing/easing.min.js"></script>
    <script src="../lib/waypoints/waypoints.min.js"></script>
    <script src="../lib/lightbox/js/lightbox.min.js"></script>
    <script src="../lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="../js/main.js"></script>
    <script src="../js/script.js"></script>
</body>

</html>