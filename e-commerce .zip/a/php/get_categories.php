<?php
// Include the database connection file
include 'conn.php';

// Get the product_id from the request if provided
$product_id = isset($_GET['product_id']) ? $_GET['product_id'] : null;

// If product_id is provided, fetch only that product's details
if ($product_id) {
    $sql_product = "SELECT product_id, product_name, description, buying_price, stock_quantity, image_url, category_name, is_on_sale, sale_price FROM product WHERE product_id = $product_id";
    $result_product = $conn->query($sql_product);
    
    if ($result_product->num_rows > 0) {
        $product = $result_product->fetch_assoc();
        $product['buying_price'] = $product['is_on_sale'] ? $product['sale_price'] : $product['buying_price'];
        echo json_encode(['product' => $product]);
    } else {
        echo json_encode(['error' => 'Product not found']);
    }
    exit;
}

// Get category and search query from the request (if provided)
$category = isset($_GET['category']) ? $_GET['category'] : '';
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

// Query to get categories from the database
$sql_categories = "SELECT category_name FROM main_categories";
$result_categories = $conn->query($sql_categories);

// Prepare an array to hold the categories
$categories = [];

if ($result_categories->num_rows > 0) {
    // Fetch each category and add to the array
    while($row = $result_categories->fetch_assoc()) {
        $categories[] = $row['category_name'];
    }
}

// Base query for products
$sql_products = "SELECT product_id, product_name, description, buying_price, stock_quantity, image_url, category_name, is_on_sale, sale_price FROM product WHERE 1=1";

// Filter by category if provided
if (!empty($category)) {
    $sql_products .= " AND category_name = '$category'";
}

// Filter by search query if provided
if (!empty($searchQuery)) {
    $sql_products .= " AND product_name LIKE '%$searchQuery%'";
}

$result_products = $conn->query($sql_products);

// Prepare an array to hold the products
$products = [];

if ($result_products->num_rows > 0) {
    // Fetch each product and add to the array
    while($row = $result_products->fetch_assoc()) {
        // If the product is on sale, use the sale price, otherwise use the normal price
        $price = $row['is_on_sale'] ? $row['sale_price'] : $row['buying_price'];
        
        // Push each product as an associative array
        $products[] = [
            'product_id' => $row['product_id'],
            'product_name' => $row['product_name'],
            'image_url' => $row['image_url'],
            'sale_price' => $price,
            'is_on_sale' => $row['is_on_sale'],
        ];
    }
}

// Return the categories and products as a JSON response
$response = [
    'categories' => $categories,
    'products' => $products
];

echo json_encode($response);
?>
