document.addEventListener("DOMContentLoaded", function () {
    // Fetch categories and all products initially
    fetchProducts();

    // Fetch categories and products using AJAX
    fetch("php/get_categories.php")
        .then((response) => response.json())
        .then((data) => {
            // Populate categories in the dropdown
            const categoryDropdown = document.getElementById("categoryDropdown");
            data.categories.forEach((category) => {
                const categoryItem = document.createElement("a");
                categoryItem.href = "#";
                categoryItem.className = "dropdown-item text-light";
                categoryItem.textContent = category;
                categoryItem.onclick = () => fetchProducts(category);
                categoryDropdown.appendChild(categoryItem);
            });
        })
        .catch((error) => console.error("Error fetching categories:", error));
});

// Function to fetch products with optional category and search parameters
function fetchProducts(category = '', search = '') {
    let url = `php/get_categories.php?category=${encodeURIComponent(category)}&search=${encodeURIComponent(search)}`;

    fetch(url)
        .then((response) => response.json())
        .then((data) => {
            // Clear the existing products
            const productList = document.getElementById("product-list");
            productList.innerHTML = '';

            // Populate products in the product list
            data.products.forEach((product) => {
                const productCard = document.createElement("div");
                productCard.className = "col-md-3";
                productCard.innerHTML = `

                
                    <div class="py-3 ">
                    <div class="product-card shadow-sm fruite border border-primary rounded overflow-hidden" data-product-id="${product.product_id}">
                        <div class="position-relative image-container">
                            <img src="${product.image_url}" alt="${product.product_name}" class="product-image">
                            ${product.is_on_sale ? '<span class="badge bg-primary position-absolute top-0 start-0 m-2">ON SALE</span>' : ""}
                        </div>
                        <div class="p-3">
                            <h5 class="product-name text-truncate">${product.product_name}</h5>
                            <p class="fw-bold mb-2">KES ${product.sale_price.toLocaleString()}</p>
                            <div class="d-flex py-1 justify-content-between ">
                                <button class="btn btn-outline-dark btn-sm" onclick="addToCart(${product.product_id}, '${product.product_name}', ${product.sale_price}, '${product.image_url}')">
                                    <i class="fas fa-cart-plus"></i> Add
                                </button>
                                <button class="btn btn-outline-secondary btn-sm" onclick="viewProduct(${product.product_id})">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button class="btn btn-outline-primary btn-sm" onclick="addToWishlist(${product.product_id})">
                                    <i class="fab fa-whatsapp "></i> Whatsapp
                                </button>
                            </div>
                        </div>
                    </div>
                     </div>
                   
                    
                `;
                productList.appendChild(productCard);
            });
        })
        .catch((error) => console.error("Error fetching products:", error));
}

// Add event listener for the search input
document.getElementById("searchInput").addEventListener("input", function () {
    const searchQuery = this.value;
    fetchProducts('', searchQuery);
});


// Function to view product details and show them in a modal
function viewProduct(productId) {
    fetch(`php/get_categories.php?product_id=${productId}`)
        .then((response) => response.json())
        .then((data) => {
            if (data.product) {
                // Populate modal fields with product data
                document.getElementById("modalProductName").textContent = data.product.product_name;
                document.getElementById("modalProductDescription").textContent = data.product.description;
                document.getElementById("modalProductPrice").textContent = data.product.sale_price.toLocaleString();
                document.getElementById("modalProductStock").textContent = data.product.stock_quantity;
                document.getElementById("modalProductImage").src = data.product.image_url;

                // Add event listener to the "Add to Cart" button to pass the correct product ID
                const addToCartButton = document.getElementById("addToCartButton");
                addToCartButton.onclick = function() {
                    addToCart(productId, data.product.product_name, data.product.sale_price, data.product.image_url);
                };

                // Show the modal
                const productModal = new bootstrap.Modal(document.getElementById("productModal"));
                productModal.show();
            } else {
                console.error("Product not found");
            }
        })
        .catch((error) => console.error("Error fetching product details:", error));
}


// Function to add item to cart
function addToCart(productId, productName, price, imageUrl) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let existingItem = cartItems.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cartItems.push({
            id: productId,
            name: productName,
            price: price,
            image: imageUrl,
            quantity: 1
        });
    }

    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartUI();
    alert(`${productName} added to cart!`);
}

// Function to update the cart UI
function updateCartUI() {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let cartItemsContainer = document.querySelector('.cart-items');
    let subtotalElement = document.getElementById('cartSubtotal');

    cartItemsContainer.innerHTML = '';
    let subtotal = 0;

    cartItems.forEach(item => {
        let itemHtml = `
<div class="card mb-2 p-1">
    <div class="d-flex align-items-center">
        <img src="${item.image}" alt="${item.name}" class="img-fluid rounded-start me-2" style="width: 60px;">
        <div class="flex-grow-1">
            <h6 class="card-title mb-1">${item.name}</h6>
            <small class="text-muted">KES ${item.price}</small>
        </div>
        <input type="number" class="form-control form-control-sm ms-2" value="${item.quantity}" min="1" style="width: 60px;" onchange="updateQuantity(${item.id}, this.value)">
        <button class="btn btn-sm btn-danger ms-2" onclick="deleteItem(${item.id})">
            <i class="fas fa-trash"></i>
        </button>
    </div>
</div>
`;

        cartItemsContainer.innerHTML += itemHtml;
        subtotal += item.price * item.quantity;
    });

    subtotalElement.textContent = `KES ${subtotal.toFixed(2)}`;
    updateCartIcon(cartItems.length);
}

// Function to update quantity
function updateQuantity(productId, newQuantity) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let item = cartItems.find(item => item.id === productId);

    if (item) {
        item.quantity = parseInt(newQuantity);
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        updateCartUI();
    }
}

// Function to delete item from cart
function deleteItem(productId) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    cartItems = cartItems.filter(item => item.id !== productId);
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartUI();
}

// Function to update the cart icon in the navbar
function updateCartIcon(itemCount) {
    let cartIcon = document.getElementById('cartIcon');
    if (cartIcon) {
        cartIcon.textContent = itemCount;
    }
}

// Load categories and products on page load
window.onload = function() {
    loadCategories();
    fetchProducts(); // Fetch all products initially
    updateCartUI(); // Initialize cart UI

    // Add event listener for search input
    document.getElementById("searchInput").addEventListener("input", searchProducts);
};

// Function to load items from localStorage to cart UI
function loadCartFromLocalStorage() {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let cartItemsContainer = document.querySelector('.cart-items');
    let subtotalElement = document.getElementById('cartSubtotal');

    cartItemsContainer.innerHTML = '';  // Clear any existing items in the UI
    let subtotal = 0;  // Initialize subtotal

    if (cartItems.length === 0) {
        cartItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
    } else {
        cartItems.forEach(item => {
            let itemHtml = `
            <div class="card mb-2 p-1">
                <div class="d-flex align-items-center">
                    <img src="${item.image}" alt="${item.name}" class="img-fluid rounded-start me-2" style="width: 60px;">
                    <div class="flex-grow-1">
                        <h6 class="card-title mb-1">${item.name}</h6>
                        <small class="text-muted">KES ${item.price}</small>
                    </div>
                    <input type="number" class="form-control form-control-sm ms-2" value="${item.quantity}" min="1" style="width: 60px;" onchange="updateQuantity(${item.id}, this.value)">
                    <button class="btn btn-sm btn-danger ms-2" onclick="deleteItem(${item.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            `;

            cartItemsContainer.innerHTML += itemHtml;
            subtotal += item.price * item.quantity;  // Calculate subtotal
        });

        subtotalElement.textContent = `KES ${subtotal.toFixed(2)}`;  // Update the subtotal in the UI
    }

    updateCartIcon(cartItems.length);  // Update the cart icon with item count
}

// Function to update the cart icon in the navbar
function updateCartIcon(itemCount) {
    let cartIcon = document.getElementById('cartIcon');
    if (cartIcon) {
        cartIcon.textContent = itemCount;
    }
}

// Call the function to load cart items from localStorage when the page loads
window.onload = function() {
    loadCartFromLocalStorage();  // Load the cart from localStorage on page load
};
