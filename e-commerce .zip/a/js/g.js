// Global cart array
let cart = [];

// Function to save the cart to localStorage
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Function to load the cart from localStorage
function loadCart() {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCart();
    }
}

// Function to add product to the cart
function addToCart(productId, productName, price, imageUrl) {
    const existingProduct = cart.find(item => item.productId === productId);

    if (existingProduct) {
        existingProduct.quantity += 1;
    } else {
        cart.push({
            productId: productId,
            productName: productName,
            price: price,
            imageUrl: imageUrl,
            quantity: 1
        });
    }

    updateCart();
    saveCart(); // Save the updated cart to localStorage
}

// Function to update the cart modal and calculate the subtotal
function updateCart() {
    const cartItemsContainer = document.querySelector(".cart-items");
    const cartSubtotal = document.getElementById("cartSubtotal");

    cartItemsContainer.innerHTML = ""; // Clear previous cart items

    let subtotal = 0;

    cart.forEach(item => {
        const cartItem = document.createElement("div");
        cartItem.className = "d-flex justify-content-between align-items-center mb-2";
        cartItem.innerHTML = `
            <div class="d-flex align-items-center">
                <img src="${item.imageUrl}" alt="${item.productName}" class="cart-item-image" style="width: 50px; margin-right: 10px;">
                <div>
                    <p class="mb-0">${item.productName}</p>
                    <small>KES ${item.price.toLocaleString()} x ${item.quantity}</small>
                </div>
            </div>
            <button class="btn btn-sm btn-danger" onclick="removeFromCart(${item.productId})"><i class="fas fa-trash-alt"></i></button>
        `;

        cartItemsContainer.appendChild(cartItem);
        subtotal += item.price * item.quantity;
    });

    cartSubtotal.textContent = `KES ${subtotal.toLocaleString()}`;
}

// Function to remove product from the cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.productId !== productId);
    updateCart();
    saveCart(); // Save the updated cart to localStorage
}

// Function to open the cart modal
function openCartModal() {
    const cartModal = new bootstrap.Modal(document.getElementById('cartModal'), {});
    cartModal.show();
}

// Load the cart when the page loads
document.addEventListener("DOMContentLoaded", function () {
    loadCart(); // Load the cart from localStorage when the page loads
});

// Function to view product details and show them in a modal
function viewProduct(productId) {
    fetch(`php/get_categories.php?product_id=${productId}`)
        .then((response) => response.json())
        .then((data) => {
            if (data.product) {
                // Populate modal fields with product data
                document.getElementById("modalProductName").textContent = data.product.product_name;
                document.getElementById("modalProductDescription").textContent = data.product.description;
                document.getElementById("modalProductPrice").textContent = data.product.sale_price.toLocaleString();
                document.getElementById("modalProductStock").textContent = data.product.stock_quantity;
                document.getElementById("modalProductImage").src = data.product.image_url;

                // Add event listener to the "Add to Cart" button to pass the correct product ID
                const addToCartButton = document.getElementById("addToCartButton");
                addToCartButton.onclick = function() {
                    addToCart(productId, data.product.product_name, data.product.sale_price, data.product.image_url);
                };

                // Show the modal
                const productModal = new bootstrap.Modal(document.getElementById("productModal"));
                productModal.show();
            } else {
                console.error("Product not found");
            }
        })
        .catch((error) => console.error("Error fetching product details:", error));
}

// Add event listener for the search input
document.getElementById("searchInput").addEventListener("input", function () {
    const searchQuery = this.value;
    fetchProducts('', searchQuery);
});

// Fetch categories and products
document.addEventListener("DOMContentLoaded", function () {
    fetchProducts();

    fetch("php/get_categories.php")
        .then((response) => response.json())
        .then((data) => {
            const categoryDropdown = document.getElementById("categoryDropdown");
            data.categories.forEach((category) => {
                const categoryItem = document.createElement("a");
                categoryItem.href = "#";
                categoryItem.className = "dropdown-item text-light";
                categoryItem.textContent = category;
                categoryItem.onclick = () => fetchProducts(category);
                categoryDropdown.appendChild(categoryItem);
            });
        })
        .catch((error) => console.error("Error fetching categories:", error));
});

function fetchProducts(category = '', search = '') {
    let url = `php/get_categories.php?category=${encodeURIComponent(category)}&search=${encodeURIComponent(search)}`;
    fetch(url)
        .then((response) => response.json())
        .then((data) => {
            const productList = document.getElementById("product-list");
            productList.innerHTML = '';

            data.products.forEach((product) => {
                const productCard = document.createElement("div");
                productCard.className = "col-md-3";
                productCard.innerHTML = `
                    <div class="product-card shadow-sm border border-primary rounded overflow-hidden" data-product-id="${product.product_id}">
                        <div class="position-relative image-container">
                            <img src="${product.image_url}" alt="${product.product_name}" class="product-image">
                            ${product.is_on_sale ? '<span class="badge bg-primary position-absolute top-0 start-0 m-2">ON SALE</span>' : ""}
                        </div>
                        <div class="p-3">
                            <h5 class="product-name text-truncate">${product.product_name}</h5>
                            <p class="fw-bold mb-2">KES ${product.sale_price.toLocaleString()}</p>
                            <div class="d-flex justify-content-between">
                                <button class="btn btn-outline-primary btn-sm" onclick="addToCart(${product.product_id}, '${product.product_name}', ${product.sale_price}, '${product.image_url}')">
                                    <i class="fas fa-cart-plus"></i> Add
                                </button>
                                <button class="btn btn-outline-secondary btn-sm" onclick="viewProduct(${product.product_id})">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button class="btn btn-outline-danger btn-sm" onclick="addToWishlist(${product.product_id})">
                                    <i class="fas fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `;
                productList.appendChild(productCard);
            });
        })
        .catch((error) => console.error("Error fetching products:", error));
}
