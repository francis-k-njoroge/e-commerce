<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>XYZ funiture </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <!--=============== CSS ===============-->
    <link rel="stylesheet" href="home/assets/css/styles.css">
    <style>
        .image-container {
            width: 100%;
            height: 200px;
            /* Adjust this value as needed */
            overflow: hidden;
        }

        .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }

        .modal-dialog-right {
            position: fixed;
            right: 0;
            top: 0;
            margin: 0;
            height: 100%;
        }

        .modal.fade .modal-dialog-right {
            transform: translateX(100%);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .modal.show .modal-dialog-right {
            transform: translateX(0);
        }

        #checkoutButton:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 181, 36, 0.3);
        }

        /* Cart item styles */
        .cart-item {
            background: #fff;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            transition: transform 0.2s ease;
            border: 1px solid #eee;
        }

        .cart-item:hover {
            transform: translateX(5px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        /* Custom scrollbar */
        .modal-body::-webkit-scrollbar {
            width: 6px;
        }

        .modal-body::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        .modal-body::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 3px;
        }

        .modal-body::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    </style>



</head>

<body>
    <!--=============== HEADER ===============-->
    <header class="header" id="header">
        <nav class="nav container">
            <a href="#" class="nav__logo">XYZ Furniture</a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item">
                        <a href="#home" class="nav__link active-link">
                            <i class="fas fa-home nav__icon"></i>
                            <span class="nav__name">Home</span>
                        </a>
                    </li>

                    <li class="nav__item">
                        <a href="#shop" class="nav__link">
                            <i class="fas fa-store nav__icon"></i>
                            <span class="nav__name">Shop</span>
                        </a>
                    </li>

                    <li class="nav__item">
                        <a href="#cart" class="nav__link " data-bs-toggle="modal" data-bs-target="#cartModal">
                            <i class="fas fa-shopping-cart nav__icon"></i>
                            <span class="nav__name">Cart</span>
                        </a>
                    </li>

                    <li class="nav__item">
                        <a href="main/checkout.php" class="nav__link">
                            <i class="fas fa-cash-register nav__icon"></i>
                            <span class="nav__name">Checkout</span>
                        </a>
                    </li>

                    <li class="nav__item">
                        <a href="#contactme" class="nav__link">
                            <i class="fas fa-envelope nav__icon"></i>
                            <span class="nav__name">Contact Me</span>
                        </a>
                    </li>
                </ul>
            </div>

            <img src="home/assets/img/perfil.png" alt="" class="nav__img">
        </nav>
    </header>

    <!-- Product Start -->
    <div class="container-fluid  py-5">

        <div class="container py-5 ">
            <h2 class="text-center">Stylish & Affordable Furniture</h2>

            <!-- Filter buttons -->
            <div class="row d-flex justify-content-center mb-4">
                <div class="col-lg-2 col-md-4 col-sm-12 mb-2">
                    <div class="btn-group w-100">
                        <button class="btn btn-primary border-secondary rounded-pill text-white w-100 btn-custom" onclick="fetchProducts()">All Products</button>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-12 mb-2">
                    <div class="nav-item dropdown w-100">
                        <a href="#" class="nav-link dropdown-toggle text-center w-100" data-bs-toggle="dropdown">Category</a>
                        <div class="dropdown-menu m-0 bg-dark rounded-4 w-100" id="categoryDropdown">
                            <!-- Categories will be loaded here dynamically -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-8 col-sm-12">
                    <input type="text" id="searchInput" class="form-control rounded-pill" placeholder="Search for items...">
                </div>
            </div>


            <!-- Products List -->
            <div class="row" id="product-list">
                <!-- Products will be dynamically populated here -->
            </div>
        </div>

    </div>
    <!-- Cart Modal Structure -->
    <div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-right" style="margin: 0; max-width: 400px; height: 100%;">
        <div class="modal-content h-100" style="border-radius: 0; box-shadow: -5px 0 15px rgba(0,0,0,0.1);">
            <!-- Header -->
            <div class="modal-header" style="background: linear-gradient(135deg, #81c408 0%, #6ea507 100%); padding: 1.5rem; border-bottom: none;">
                <h5 class="modal-title text-white d-flex align-items-center" id="cartModalLabel" style="font-size: 1.25rem; font-weight: 600;">
                    <i class="fas fa-shopping-bag me-2"></i>
                    Your Shopping Cart
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <!-- Body -->
            <div class="modal-body" style="background-color: #ffffff; padding: 1.5rem; overflow-y: auto;">
                <div class="cart-items" style="min-height: 200px;">
                    <!-- Empty cart message -->
                    <div class="text-center py-4 empty-cart-message">
                        <i class="fas fa-shopping-cart mb-3" style="font-size: 3rem; color: #e0e0e0;"></i>
                        <p class="text-muted">Your cart is empty</p>
                    </div>
                    <!-- Cart items will be dynamically inserted here -->
                </div>
            </div>
            
            <!-- Footer -->
            <div class="modal-footer" style="background-color: #f8f9fa; border-top: 1px solid #eee; padding: 1.5rem;">
                <div class="w-100">
                    <!-- Summary -->
                    <div class="summary-section mb-3">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Subtotal</span>
                            <span id="cartSubtotal" style="font-weight: 600;">KES 0</span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span class="text-muted">Delivery</span>
                            <span class="text-success">Free</span>
                        </div>
                        <div class="d-flex justify-content-between" style="font-size: 1.1rem;">
                            <span style="font-weight: 600;">Total</span>
                            <span id="cartTotal" style="font-weight: 600;">KES 0</span>
                        </div>
                    </div>
                    
                    <!-- Checkout Button -->
                    <button id="checkoutButton" class="btn w-100" 
                            style="background: linear-gradient(135deg, #ffb524 0%, #ff9500 100%); 
                                   border: none; 
                                   color: white; 
                                   font-weight: 600; 
                                   padding: 12px 20px;
                                   border-radius: 8px;
                                   transition: transform 0.2s ease;"
                            onclick="window.location.href='main/checkout.php';">
                        <i class="fas fa-lock me-2"></i> Secure Checkout
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Product Modal -->
    <div class="modal fade" id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content" style="border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
                <div class="modal-header" style="background-color: #81c408; color: white; border-bottom: none;">
                    <h5 class="modal-title" id="productModalLabel" style="font-weight: bold;">Product Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="color: white;"></button>
                </div>
                <div class="modal-body" style="background-color: #f8f9fa; padding: 30px;">
                    <div class="row">
                        <div class="col-md-6">
                            <img id="modalProductImage" src="/api/placeholder/400/400" alt="Product Image" class="img-fluid" style="border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                        </div>
                        <div class="col-md-6">
                            <h3 id="modalProductName" style="color: #333; margin-bottom: 15px;"></h3>
                            <p id="modalProductDescription" style="color: #666; margin-bottom: 20px;"></p>
                            <p style="font-size: 1.2em; color: #81c408; font-weight: bold;">Price: KES <span id="modalProductPrice"></span></p>
                            <p style="margin-bottom: 20px;">In Stock: <span id="modalProductStock" style="font-weight: bold;"></span></p>

                            <div class="mb-3">
                                <label for="quantity" class="form-label">Quantity:</label>
                                <input type="number" id="quantity" class="form-control" value="1" min="1" style="max-width: 100px;">
                            </div>

                            <div class="d-flex gap-2">
                                <button id="addToCartButton" class="btn btn-primary" style="background-color: #ffb524; border-color: #ffb524; color: white; font-weight: bold; padding: 10px 20px;">
                                    <i class="fas fa-shopping-cart me-2"></i> Add to Cart
                                </button>
                                <button type="button" class="btn btn-outline-danger" style="border-color: #ffb524; color: #ffb524; font-weight: bold; padding: 10px 20px;">
                                    <i class="fas fa-heart me-2"></i> Wishlist
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5">
        <div class="container py-5">
            <div class="pb-4 mb-4" style="border-bottom: 1px solid rgba(226, 175, 24, 0.5) ;">
                <div class="row g-4">
                    <div class="col-lg-3">
                        <a href="#">
                            <h1 class="text-primary mb-0">XYZ Furniture</h1>
                            <p class="text-secondary mb-0">Quality products</p>
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <div class="position-relative mx-auto">
                            <input class="form-control border-0 w-100 py-3 px-4 rounded-pill" type="email " placeholder="Your Email">
                            <button type="submit" class="btn btn-primary border-0 border-secondary py-3 px-4 position-absolute rounded-pill text-white" style="top: 0; right: 0;">Subscribe Now</button>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="d-flex justify-content-end pt-3">
                            <a class="btn  btn-outline-secondary me-2 btn-md-square rounded-circle" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-secondary me-2 btn-md-square rounded-circle" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-secondary me-2 btn-md-square rounded-circle" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-secondary btn-md-square rounded-circle" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- Footer End -->

    <!-- Copyright Start -->
    <div class="container-fluid copyright bg-dark py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    <span class="text-light"><a href="#"><i class="fas fa-copyright text-light me-2"></i>Your Site Name</a>, All right reserved.</span>
                </div>
                <div class="col-md-6 my-auto text-center text-md-end text-white">
                    <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
                    <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
                    <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
                    Designed By <a class="border-bottom" href="#">Amoh tech</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->

    <script src="home/assets/js/main.js"></script>

    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script src="js/script.js"></script>
</body>

</html>